# Aurora PostgreSQL MCP Connection Setup

## Overview
Successfully configured the db-performance MCP server to connect to Aurora PostgreSQL running locally on port 5436.

## Connection Details

### Aurora PostgreSQL Configuration
- **Connection Name**: `aurora-postgres-local`
- **Host**: `localhost`
- **Port**: `5436`
- **Database**: `postgres`
- **User**: `isv_user`
- **SSL**: Disabled (local connection)

### Database Information
- **PostgreSQL Version**: 16.8 on aarch64-unknown-linux-gnu
- **Current Schema**: public (0 tables)

## Configuration File

The Aurora PostgreSQL connection has been added to [`db-config.json`](db-config.json:15-23):

```json
{
  "databases": {
    "postgres": {
      "enabled": true,
      "connections": [
        {
          "name": "hvdb-postgres",
          "host": "localhost",
          "port": 5432,
          "database": "hvdb",
          "user": "postgres",
          "password": "object00",
          "ssl": true
        },
        {
          "name": "aurora-postgres-local",
          "host": "localhost",
          "port": 5436,
          "database": "postgres",
          "user": "isv_user",
          "password": "ftYzWLZsYn6wmlnSXPQn",
          "ssl": false
        }
      ]
    }
  }
}
```

## Testing the Connection

A test script has been created at [`test-aurora-connection.cjs`](test-aurora-connection.cjs) to verify connectivity:

```bash
cd db-performance-server
node test-aurora-connection.cjs
```

### Test Results
✓ Successfully connected to Aurora PostgreSQL!
- Database: postgres
- User: isv_user
- Version: PostgreSQL 16.8
- Tables in public schema: 0

## Using with MCP

### Available Tools

Once the MCP server is restarted, you can use these tools with the `aurora-postgres-local` connection:

1. **analyze_postgres_queries** - Analyze slow queries using pg_stat_statements
2. **check_postgres_connections** - Monitor connection pool status
3. **get_postgres_table_stats** - Get table statistics and sizes
4. **check_postgres_locks** - Identify blocking queries and lock contention
5. **get_postgres_cache_stats** - Monitor buffer cache hit ratios
6. **get_postgres_index_usage** - Analyze index usage patterns
7. **get_postgres_database_size** - Get database size information
8. **execute_postgres_query** - Execute custom SQL queries

### Example Usage

```typescript
// List all available connections
use_mcp_tool("db-performance", "list_connections", {})

// Get database size
use_mcp_tool("db-performance", "get_postgres_database_size", {
  "connection": "aurora-postgres-local"
})

// Analyze slow queries
use_mcp_tool("db-performance", "analyze_postgres_queries", {
  "connection": "aurora-postgres-local",
  "limit": 10
})

// Execute custom query
use_mcp_tool("db-performance", "execute_postgres_query", {
  "connection": "aurora-postgres-local",
  "query": "SELECT * FROM information_schema.tables WHERE table_schema = 'public'"
})
```

## Next Steps

1. **Restart Bob** to reload the MCP server with the new configuration
2. **Verify MCP Connection**: Use `list_connections` tool to confirm Aurora connection is available
3. **Run Performance Analysis**: Use the various PostgreSQL tools to analyze database performance
4. **Monitor Queries**: Set up pg_stat_statements extension if not already enabled for query analysis

## Troubleshooting

### MCP Server Not Showing Tools
- Restart Bob to reload the MCP server configuration
- Check that the db-performance server is enabled in MCP settings
- Verify the build was successful: `npm run build`

### Connection Issues
- Verify Aurora PostgreSQL is running on port 5436
- Check credentials are correct
- Ensure no firewall blocking localhost:5436
- Test connection using the test script

### Configuration Issues
- Ensure db-config.json has valid JSON syntax
- Verify the connection is in the correct location: `databases.postgres.connections[]`
- Check environment variable DB_CONFIG_PATH points to the correct file

## Related Files

- [`db-config.json`](db-config.json) - Main configuration file
- [`test-aurora-connection.cjs`](test-aurora-connection.cjs) - Connection test script
- [`src/index.ts`](src/index.ts) - MCP server implementation
- [`../../../.bob/settings/mcp_settings.json`](../../../.bob/settings/mcp_settings.json) - Bob MCP settings

## Status

✅ Configuration complete
✅ Connection tested successfully
⏳ Awaiting MCP server restart to use tools